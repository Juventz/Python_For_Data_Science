def count_in_list(lst, item):
    """Count the number of times item appears in lst."""
    return lst.count(item)
